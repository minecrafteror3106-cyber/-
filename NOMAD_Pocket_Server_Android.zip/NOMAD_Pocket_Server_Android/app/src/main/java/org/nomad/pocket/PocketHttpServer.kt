package org.nomad.pocket

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.util.UUID
import kotlin.concurrent.thread

/**
 * Minimal loopback-only HTTP server. It binds to 127.0.0.1, not the Wi-Fi network.
 * The server is active while the app is open and is stopped when the Activity closes.
 */
class PocketHttpServer(context: Context) {
    private val prefs = context.getSharedPreferences("nomad_store", Context.MODE_PRIVATE)
    @Volatile private var running = false
    private var socket: ServerSocket? = null

    fun start() {
        if (running) return
        socket = ServerSocket(8765, 16, java.net.InetAddress.getByName("127.0.0.1"))
        running = true
        thread(name = "nomad-http") {
            while (running) {
                try {
                    val client = socket?.accept() ?: break
                    thread(name = "nomad-client") { handle(client) }
                } catch (_: Exception) {
                    if (running) continue else break
                }
            }
        }
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        socket = null
    }

    private fun handle(client: Socket) {
        client.use { s ->
            try {
                s.soTimeout = 5000
                val input = BufferedInputStream(s.getInputStream())
                val headerBuffer = ByteArrayOutputStream()
                var matched = 0
                val marker = byteArrayOf(13, 10, 13, 10)
                while (headerBuffer.size() < 16384 && matched < 4) {
                    val b = input.read()
                    if (b == -1) return
                    headerBuffer.write(b)
                    matched = when {
                        b == marker[matched] -> matched + 1
                        b == marker[0].toInt() -> 1
                        else -> 0
                    }
                }
                val headerText = headerBuffer.toString("UTF-8")
                val lines = headerText.split("\r\n")
                val first = lines.firstOrNull()?.split(" ") ?: return
                val method = first.getOrNull(0) ?: "GET"
                val path = first.getOrNull(1)?.substringBefore("?") ?: "/"
                val contentLength = lines.firstOrNull { it.startsWith("Content-Length:", true) }
                    ?.substringAfter(":")?.trim()?.toIntOrNull()?.coerceIn(0, 1_000_000) ?: 0
                val body = ByteArray(contentLength)
                var offset = 0
                while (offset < contentLength) {
                    val count = input.read(body, offset, contentLength - offset)
                    if (count <= 0) break
                    offset += count
                }
                val bodyText = String(body, 0, offset, StandardCharsets.UTF_8)
                val (status, contentType, response) = route(method, path, bodyText)
                val bytes = response.toByteArray(StandardCharsets.UTF_8)
                val reason = if (status == 200) "OK" else if (status == 404) "Not Found" else "Bad Request"
                val headers = "HTTP/1.1 $status $reason\r\n" +
                    "Content-Type: $contentType; charset=utf-8\r\n" +
                    "Content-Length: ${bytes.size}\r\n" +
                    "Cache-Control: no-store\r\n" +
                    "Connection: close\r\n\r\n"
                s.getOutputStream().apply {
                    write(headers.toByteArray(StandardCharsets.UTF_8))
                    write(bytes)
                    flush()
                }
            } catch (_: Exception) {
                // A disconnected browser request should not stop the local server.
            }
        }
    }

    private fun route(method: String, path: String, body: String): Triple<Int, String, String> {
        return when {
            method == "GET" && path == "/" ->
                Triple(200, "text/html", assetHtml())
            method == "GET" && path == "/api/status" -> {
                val json = JSONObject()
                    .put("name", "NOMAD Pocket Server")
                    .put("version", "0.1.0")
                    .put("server", "running")
                    .put("scope", "phone-only")
                    .put("offlineReady", true)
                Triple(200, "application/json", json.toString())
            }
            method == "GET" && path == "/api/notes" ->
                Triple(200, "application/json", prefs.getString("notes", "[]") ?: "[]")
            method == "POST" && path == "/api/notes" -> {
                try {
                    val item = JSONObject(body)
                    val title = item.optString("title").trim().take(120)
                    val content = item.optString("content").trim().take(12000)
                    if (title.isBlank() || content.isBlank()) {
                        Triple(400, "application/json", """{"error":"Укажи заголовок и текст"}""")
                    } else {
                        val notes = JSONArray(prefs.getString("notes", "[]") ?: "[]")
                        val saved = JSONObject()
                            .put("id", UUID.randomUUID().toString())
                            .put("title", title)
                            .put("content", content)
                            .put("createdAt", System.currentTimeMillis())
                        notes.put(saved)
                        prefs.edit().putString("notes", notes.toString()).apply()
                        Triple(200, "application/json", saved.toString())
                    }
                } catch (_: Exception) {
                    Triple(400, "application/json", """{"error":"Некорректные данные"}""")
                }
            }
            method == "POST" && path == "/api/notes/delete" -> {
                try {
                    val id = JSONObject(body).optString("id")
                    val old = JSONArray(prefs.getString("notes", "[]") ?: "[]")
                    val updated = JSONArray()
                    for (i in 0 until old.length()) {
                        val note = old.getJSONObject(i)
                        if (note.optString("id") != id) updated.put(note)
                    }
                    prefs.edit().putString("notes", updated.toString()).apply()
                    Triple(200, "application/json", """{"ok":true}""")
                } catch (_: Exception) {
                    Triple(400, "application/json", """{"error":"Не удалось удалить"}""")
                }
            }
            else -> Triple(404, "application/json", """{"error":"Not found"}""")
        }
    }

    private fun assetHtml(): String {
        // The UI is embedded as a string so the app needs no external web server or libraries.
        return HTML
    }

    companion object {
        private val HTML = """
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<meta name="theme-color" content="#101827">
<title>NOMAD Pocket Server</title>
<style>
:root{color-scheme:dark;--bg:#0b1220;--panel:#131e30;--panel2:#19263b;--line:#26364e;--txt:#edf3ff;--muted:#9fb0c9;--accent:#71d6b3;--blue:#86aaff}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 80% -10%,#1b3850 0,transparent 38%),var(--bg);color:var(--txt);font:15px system-ui,-apple-system,sans-serif}
header{padding:22px 18px 16px;position:sticky;top:0;background:#0b1220ed;backdrop-filter:blur(14px);border-bottom:1px solid var(--line);z-index:2}
.brand{display:flex;align-items:center;gap:12px}.logo{width:44px;height:44px;border-radius:14px;background:linear-gradient(135deg,#6fe0b7,#5b9eff);display:grid;place-items:center;color:#081521;font-weight:900;font-size:21px}
h1{font-size:19px;margin:0}header p{margin:3px 0 0;color:var(--muted);font-size:12px}
main{padding:17px;max-width:760px;margin:auto}.status{display:flex;align-items:center;gap:9px;color:var(--accent);font-size:13px;margin:4px 0 16px}.dot{width:8px;height:8px;border-radius:50%;background:var(--accent);box-shadow:0 0 12px var(--accent)}
h2{font-size:17px;margin:22px 0 12px}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:11px}.card{background:linear-gradient(145deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:17px;padding:15px;min-height:112px}.ico{font-size:23px}.card b{display:block;margin:9px 0 3px}.card small{color:var(--muted);line-height:1.4}.wide{grid-column:1/-1}
button{border:0;border-radius:12px;padding:12px 15px;background:var(--accent);color:#092017;font-weight:750;font-size:14px}
button.secondary{background:var(--panel2);color:var(--txt);border:1px solid var(--line)}button.danger{background:#482632;color:#ffdce3}
.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
.panel{background:var(--panel);border:1px solid var(--line);border-radius:17px;padding:15px;margin-top:12px}
input,textarea{width:100%;padding:12px;border-radius:11px;border:1px solid var(--line);background:#0d1727;color:var(--txt);font:inherit;margin:6px 0 10px}
textarea{min-height:110px;resize:vertical}.muted{color:var(--muted);font-size:12px}.note{padding:12px 0;border-bottom:1px solid var(--line)}.note:last-child{border:0}.note h3{font-size:14px;margin:0 0 5px}.note p{white-space:pre-wrap;margin:0;color:var(--muted);font-size:13px;overflow-wrap:anywhere}
.tag{display:inline-block;padding:5px 9px;border:1px solid var(--line);border-radius:30px;color:var(--muted);font-size:11px}
footer{text-align:center;color:#7587a2;font-size:11px;padding:28px 10px}
</style></head>
<body>
<header><div class="brand"><div class="logo">N</div><div><h1>NOMAD Pocket Server</h1><p>Твой личный центр знаний · Android</p></div></div></header>
<main>
<div class="status"><span class="dot"></span><span id="serverState">Локальный сервер запущен</span><span class="tag">PHONE ONLY</span></div>
<div class="grid">
<div class="card"><div class="ico">🧠</div><b>Локальный ИИ</b><small>Модуль подготовки. Подключение локальной модели появится в следующей версии.</small></div>
<div class="card"><div class="ico">📚</div><b>Библиотека</b><small>Раздел для книг, справочников и офлайн-материалов.</small></div>
<div class="card"><div class="ico">🗺️</div><b>Карты</b><small>Место для офлайн-карт и справочной информации.</small></div>
<div class="card"><div class="ico">🎓</div><b>Обучение</b><small>Личные учебные материалы и курсы.</small></div>
</div>
<h2>Быстрые заметки</h2>
<div class="panel">
<label class="muted" for="title">Заголовок</label><input id="title" maxlength="120" placeholder="Например, идеи проекта">
<label class="muted" for="content">Текст</label><textarea id="content" maxlength="12000" placeholder="Запиши важную информацию..."></textarea>
<button onclick="saveNote()">Сохранить заметку</button>
<div id="message" class="muted" style="margin-top:9px"></div>
</div>
<h2>Сохранённое на телефоне</h2>
<div class="panel"><div id="notes"><span class="muted">Загрузка...</span></div></div>
<h2>Состояние сервера</h2>
<div class="panel"><div class="muted">Адрес: http://127.0.0.1:8765</div><div class="muted" style="margin-top:6px">Доступ ограничен этим телефоном. Сервер работает, пока открыто приложение.</div><div class="actions"><button class="secondary" onclick="refreshAll()">Обновить состояние</button><span class="tag">Данные хранятся локально</span></div></div>
</main><footer>NOMAD Pocket Server · MVP 0.1.0<br>Работает локально, без внешнего аккаунта</footer>
<script>
async function api(path,options={}){const r=await fetch(path,{headers:{'Content-Type':'application/json'},...options});if(!r.ok)throw new Error('HTTP '+r.status);return r.json()}
async function refreshAll(){try{const s=await api('/api/status');document.getElementById('serverState').textContent='Сервер активен · версия '+s.version;await loadNotes()}catch(e){document.getElementById('serverState').textContent='Нет соединения с локальным сервером'}}
async function loadNotes(){const notes=await api('/api/notes');const box=document.getElementById('notes');if(!notes.length){box.innerHTML='<span class="muted">Пока нет заметок. Создай первую выше.</span>';return}
box.innerHTML='';[...notes].reverse().forEach(n=>{const item=document.createElement('div');item.className='note';const h=document.createElement('h3');h.textContent=n.title;const p=document.createElement('p');p.textContent=n.content;const b=document.createElement('button');b.className='secondary';b.style.marginTop='9px';b.textContent='Удалить';b.onclick=()=>deleteNote(n.id);item.append(h,p,b);box.append(item)})}
async function saveNote(){const title=document.getElementById('title').value.trim(),content=document.getElementById('content').value.trim(),msg=document.getElementById('message');if(!title||!content){msg.textContent='Заполни заголовок и текст.';return}try{await api('/api/notes',{method:'POST',body:JSON.stringify({title,content})});document.getElementById('title').value='';document.getElementById('content').value='';msg.textContent='Сохранено на телефоне.';await loadNotes()}catch(e){msg.textContent='Не удалось сохранить.'}}
async function deleteNote(id){try{await api('/api/notes/delete',{method:'POST',body:JSON.stringify({id})});await loadNotes()}catch(e){alert('Не удалось удалить заметку')}}
refreshAll();
</script></body></html>
        """.trimIndent()
    }
}
